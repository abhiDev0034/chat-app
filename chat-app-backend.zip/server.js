// server.js
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const cors = require('cors');
const path = require('path');

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: '*',
  },
});

app.use(cors());
app.use(express.static(path.join(__dirname, 'public')));

io.on('connection', (socket) => {
  console.log('User connected:', socket.id);

  socket.on('join', (username) => {
    socket.username = username;
    io.emit('userJoined', `${username} joined the chat`);
  });

  socket.on('chatMessage', (msg) => {
    io.emit('chatMessage', { user: socket.username, msg });
  });

  socket.on('sendImage', (data) => {
    io.emit('sendImage', { user: socket.username, data });
  });

  socket.on('sendFile', (data) => {
    io.emit('sendFile', { user: socket.username, data });
  });

  socket.on('sendLocation', (location) => {
    io.emit('sendLocation', { user: socket.username, location });
  });

  socket.on('disconnect', () => {
    io.emit('userLeft', `${socket.username} left the chat`);
    console.log('User disconnected:', socket.id);
  });
});

const PORT = process.env.PORT || 5000;
server.listen(PORT, () => console.log(`Server running on port ${PORT}`));